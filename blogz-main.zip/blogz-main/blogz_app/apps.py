from django.apps import AppConfig


class BlogzAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'blogz_app'
