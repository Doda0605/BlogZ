from typing import Any
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django import forms
from .models import ProfileModel
from blogz_app.models import Account


class SignUpForm(UserCreationForm):
    email = forms.EmailField()
    is_moderator = forms.BooleanField(required=False, label='Do you want to be a moderator?')

    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2', 'is_moderator']

    def __init__(self, *args, **kwargs):
        super(SignUpForm, self).__init__(*args, **kwargs)
        for fieldname in ['username', 'email', 'password1', 'password2']:
            self.fields[fieldname].help_text = None

    def save(self, commit=True):
        user = super().save(commit=False)
        if commit:
            user.save()
            is_moderator = self.cleaned_data.get('is_moderator')  
            account = Account.objects.create(user=user, is_moderator=is_moderator) 
        return user



class UserUpdateForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['username', 'email']

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super(UserUpdateForm, self).__init__(*args, **kwargs)

        for fieldname in ['username', 'email']:
            self.fields[fieldname].help_text = None

class ProfileUpdateForm(forms.ModelForm):
    class Meta:
        model = ProfileModel
        fields = ['image']