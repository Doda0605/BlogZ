TITLE: "Blogz"

Table of contents
1. Introduction
2. Overall description
3. Specific requirements
4. System Interfaces
5. Other Nonfunctional requirements
6. Other requirements

1. Introduction

1.1 Purpose

The purpose of this document is to provide a Software Requirements
Specification (SRS) for the development of “Blogz”, a web
application that enables users to post and see posts quickly and
conveniently. This document describes the requirements of the web
application from the perspectives of the user, system, and customer.

1.2 Document Conventions

This document is written using the IEEE 830-1998 standard for software
requirements specifications. It will include user, system, and customer
requirements for the completion of the project.

1.3 Intended Audience and Reading Suggestions

This document is intended for the revision purposes for a faculty course 
named "Programsko inženjerstvo" at FERIT and for the developers and
designers working on the "Blogz" project. It will include user, system 
and customer requirements for the completion of the project.

1.4 Product Scope

The scope of "Blogz" is to create a web application that allows
users to make posts quickly and easily. It also provides a feedback in 
form of user comments.

1.5 References

1. Django 5.0.1 documentation
2. Bootstrap 4.6
3. crispy for bootstrap4
4. pillow
5. IEEE 830-1998: IEEE Standard for Software Requirements Specifications (IEEE, 1998).

1.6 Overview

The "Blogz" web application will be a platform for users to make posts
quickly and efficiently. The application will also provide a feedback
feature by using comments under each post.

2. Overall Description

2.1 Product Perspective

Blogz is a web application designed to help users make, see and
comment to posts made by community.

The user interface is designed with focus on ease of use and visual clarity.
Each user can make his own posts while also being able to see and comment to
the posts of the other users.

Blogz also has a feature to remove or edit your own posts for the purposes of
fixing or removing posts you are not satisfied with.

Blogz is a self-contained web application that will be hosted on a web server.
It will be accessible through a web browser.

2.2 Product Functions

"Blogz" will provide the following functions:
	-User interface: Users will be able to see posts made by other users while also
having the option of seeing each posts comments made by other users.
	-Post and comment making: Users will have a quick and easy access to post 
and comment creating.
	-Editing profiles: Users will have a option of editing their profile.
To be more precise, the will have a option to change their username, email address
and profile image.

2.3 User Classes and Characteristics

The product will have three logical user classes: Admin, User and Moderator.

2.3.1 Admin

Admin users will be able to manage the web application, including managing users,
users' profiles, users'posts and users' comments.

2.3.2 User

Users will be able to make posts and comments while also being able to see other 
users posts and comments.

2.3.3 Moderator

Moderator users will be able to manage posts.

2.4 Operating Enviroment

The web application will be hosted on a web server. It will be accessible through a web
browser.

2.5 Design and Implementation Constraints

The web application will be written in Python using the Django framework. It will be
hosted on a web server. The data will be stored in Django db.sqlite3 database.

2.6 User Documentation

No documentation will be provided to users.

2.7 Assumptions and Dependancies

The application will not be dependent on anything outside itself.

3. Specific Requirements

3.1 Functional Requirements

3.1.1 User Requirements

Req U1 - The web application will allow users to register for an account.

Users will provide their name, email address, and password. The web application 
will verify that the email address is unique and not already used by another user.

3.1.1.2 User Login

Req U2 - The web application will allow users to log in to their account.
 
Users will provide their username and password. The web application 
will verify that the username and password match the information in the database.

3.1.1.3 User Logout

Req U3 - The web application will allow users to log out of their account.

Users will click on a "Log Out" button in the Navigation. The web application will
terminate the user's session.

3.1.1.4 User Profile

Req U4 - The web application will provide a profile for users to view
and edit their account information.

The profile will include the following information:

User's username
User's email address
User's moderator status
User's profile picture


The user will be able to change their email address, username and profile picture on this
page.

3.1.1.5 Making posts

Req U5 - The web application will allow users to make posts.

Users will provide the
following information:

Post title
Post content

The web application will make a new post using provided information while
also adding current date when the post was made and the creator's profile
icon and name.

3.1.1.6

Req U6 - The web application will allows users to make comments.

Users will have an option of seeing and making their own comments under any
post.

Users will provide the following information:

Post content

The web application will make a new post using provided information while
also adding the creator's name to the start of the comment.

3.1.2 Moderator Requirements

3.1.2.1 Creating moderator user

Req U7 - The web aplication will allow users to create moderator accounts.

Users will be presented a option to make their account moderator accounts.

3.1.2.2 

Req U8 - The web application will allow moderator users to manage posts.

The moderator users will be able to see all posts and will have an option to
edit, remove and leave a comment under any of them.

3.1.3 Admin Requirements

Admin requirements focus on the specific functionalities that give them
full control of the web application and it's users. The Admings use the
Django Admin interface to manage the system.

3.1.3.1 Admin dashboard

Req A1 - The web application will provide a dashboard for admins to
manage the system.

The dashboard will use the Django Admin interface. The dashboard will allow
admins to manage the following:
-Users(create, edit, delete)
-Comments(create, edit, delete)
-Posts(create, edit, delete)

3.2 Usability Requirements

The web application will be designed to be easy to use, responsive and intuitive.

3.3 Reliabilty Requirements

None at this time.

3.4 Performance requirements

None at this time.

3.5 Supportability Requirements

None at this time.

3.6 Design Constraints

None at this time.

4. System Interfaces

4.1 User Interfaces

The application will have a user interface that is accessible via a web browser.
The interface will be designed to be intuitive and user-friendly for most devices.

The web application wil use a standard web interface with a top navigation bar and
a main content area. The web application will be primarily used on a desktop computer
and a responsive design is not required.

The top navigation bar will have the following links:
-On the left side:
	-Logo(a link to the home page)
-On the right side:
	-Sign up(a link to the Sign Up Page) if the user is not logged in
	-Login(a link to the Login Page) if the user is not logged in
	-Profile(a link to the logged in user's Profile Page) if the user is logged in
	-Log Out(a link to the Log Out Page) if the user is logged in

4.2 Hardware Interfaces

The application will be hosted on a secure web server running on Linux or Windows.

4.3 Software Interfaces

The application will use Django 5.0.1, the database will be Django's db.sqlite3 database
and frontend will be enchanced by Bootstrap 4.6 and crispy forms.

4.4 Communication Interfaces

None at this time.

5. Other Nonfunctional Requirements

The application will use the Django's default User management system. The
application will use Django's default authentication system. The application
will use Django's default authorization system.

5.2 Safety Requirements

The application will be designed to prevent the user from performing any unsafe actions
or operations.

5.3 Business Rules

The application will have business rules in place to ensure the safety and security of user data.

5.4 Quality Attributes
The application must have a high quality user interface with good usability and responsiveness.
The application must also have an uptime of at least 99.

6. Other Requirements

6.1 Business Requirements

None at this time.

6.2 Regulatory Requirements

None at this time.
